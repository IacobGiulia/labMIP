package Persistenta;
import java.io.*;
import java.util.List;
import Model.Film;
import Model.Serial;
public class PersistentaTxt {

    private static final String FILME_FILE = "filme.txt";
    private static final String SERIALE_FILE = "seriale.txt";


    public static void scriereFilmeInFisier(List<Film> filme) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILME_FILE))) {
            for (Film film : filme) {
                writer.write(film.getTitlu() + ";" + film.getGen() + ";" + film.getAn() + ";" + film.getRating());
                writer.newLine(); // adaugă un newline între filme
            }
        }
    }

    public static void scriereSerialeInFisier(List<Serial> seriale) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SERIALE_FILE))) {
            for (Serial serial : seriale) {
                writer.write(serial.getTitlu() + ";" + serial.getSezoane());
                writer.newLine();
            }
        }
    }


    public static void citireFilmeDinFisier(List<Film> filme) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILME_FILE))) {
            String linie;
            while ((linie = reader.readLine()) != null) {
                String[] date = linie.split(";");
                String titlu = date[0];
                String gen = date[1];
                int an = Integer.parseInt(date[2]);
                double rating = Double.parseDouble(date[3]);
                filme.add(new Film(titlu, gen, an, rating));
            }
        }
    }

    public static void citireSerialeDinFisier(List<Serial> seriale) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(SERIALE_FILE))) {
            String linie;
            while ((linie = reader.readLine()) != null) {
                String[] date = linie.split(";");
                String titlu = date[0];
                int sezoane = Integer.parseInt(date[1]);
                seriale.add(new Serial(titlu, sezoane));
            }
        }
    }
}