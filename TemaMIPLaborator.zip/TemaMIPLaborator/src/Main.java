import Model.Film;
import Model.Serial;

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import Persistenta.PersistentaTxt;

public class Main {

    private static List<Film> filme = new ArrayList<>();
    private static List<Serial> seriale = new ArrayList<>();

    public static void main(String[] args) {

        try {
            PersistentaTxt.citireFilmeDinFisier(filme);
            PersistentaTxt.citireSerialeDinFisier(seriale);
        } catch (IOException e) {
            System.out.println("Eroare la citirea fișierelor: " + e.getMessage());
        }

        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("\n Bine ati venit la Manager-ul pentru filme si seriale! " +
                    "Acestea sunt optiunile dumneavoastra");
            System.out.println("1) Afiseaza lista de filme si de seriale.");
            System.out.println("2) Cauta un titlu de film sau de serial.");
            System.out.println("3) Adauga un film.");
            System.out.println("4) Adauga un serial.");
            System.out.println("5) Filtreaza filmele sau serialele.");
            System.out.println("6) Iesi.");
            System.out.println("Optiunea dumneavoastra:");

            int optiune = scanner.nextInt();
            scanner.nextLine();

            switch (optiune) {
                case 1:
                    afisareColectie();
                    break;
                case 2:
                    cautareTitlu(scanner);
                    break;
                case 3:
                    adaugareFilm(scanner);
                    break;
                case 4:
                    adaugareSerial(scanner);
                    break;
                case 5:
                    filtrareFilmeSeriale(scanner);
                    break;
                case 6:
                    running = false;

                    try {
                        // Salvarea datelor înainte de a închide aplicația
                        PersistentaTxt.scriereFilmeInFisier(filme);
                        PersistentaTxt.scriereSerialeInFisier(seriale);
                    } catch (IOException e) {
                        System.out.println("Eroare la salvarea fișierelor: " + e.getMessage());
                    }

                    System.out.println("La revedere!");
                    break;
                default:
                    System.out.println("Optiunea este invalida!");
            }
        }
    }

    private static void afisareColectie()
    {
        System.out.println("Colectia de filme: \n");

        for(Film film : filme)
        {
            System.out.println(film);
        }
        System.out.println("\nColectia de seriale: \n");

        for(Serial serial : seriale)
        {
            System.out.println(serial);
        }

    }

    private static void cautareTitlu(Scanner scanner)
    {
        System.out.println("\nCe film/serial doriti sa cautati?\n");
        String titlu = scanner.nextLine();
        boolean gasit = false;

        for(Film film : filme)
        {
            if(film.getTitlu().equalsIgnoreCase(titlu))
            {
                gasit = true;
                System.out.println("S-a gasit titlul de film:" + titlu);
            }
        }

        for(Serial serial : seriale)
        {
            if(serial.getTitlu().equalsIgnoreCase(titlu))
            {
                gasit = true;
                System.out.println("S-a gasit titlul de serial:" + titlu);
            }
        }

        if(!gasit)
            System.out.println("Nu s-a gasit titlul!\n");

    }

    private static void adaugareFilm(Scanner scanner)
    {
        System.out.println("Ce film doriti sa adaugati?");
        String filmDeAdaugat = scanner.nextLine();

        System.out.println("Care este genul filmului pe care doriti sa il adaugati?");
        String genFilm = scanner.nextLine();

        System.out.println("Care este anul lansarii filmului pe care doriti sa il adaugati?");
        int anLansare = scanner.nextInt();

        System.out.println("Care este rating-ul filmului pe care doriti sa il adaugati?");
        double ratingFilm = scanner.nextDouble();

        filme.add(new Film(filmDeAdaugat, genFilm, anLansare, ratingFilm));
        System.out.println("Filmul a fost adaugat cu succes!");
    }

    private static void adaugareSerial(Scanner scanner)
    {
        System.out.println("Ce serial doriti sa adaugati?");
        String serialDeAdaugat = scanner.nextLine();

        System.out.println("Cate sezoane are serialul pe care doriti sa il adaugati?");
        int nrSezoane = scanner.nextInt();

        seriale.add(new Serial(serialDeAdaugat, nrSezoane));
        System.out.println("Serialul a fost adaugat cu succes!");
    }

    private static void filtrareFilmeSeriale(Scanner scanner)
    {
        System.out.println("Dupa ce criteriu doriti sa filtrati?\n");
        System.out.println("1) Filtrati filmele dupa gen");
        System.out.println("2) Filtrati filmele dupa rating");
        System.out.println("3) Filtrati serialele dupa numarul de sezoane");

        int optiune = scanner.nextInt();
        scanner.nextLine();

        switch (optiune) {
            case 1:
                System.out.println("Introduceti genul pentru filtrare:");
                String gen = scanner.nextLine();
                for (Film film : filme) {
                    if (film.filtreaza(gen)) {
                        System.out.println(film);
                    }
                }
                break;
            case 2:
                System.out.println("Introduceti rating-ul minim pentru filtrare:");
                double rating = scanner.nextDouble();
                for (Film film : filme) {
                    if (film.filtreaza(rating)) {
                        System.out.println(film);
                    }
                }
                break;
            case 3:
                System.out.println("Introduceti numarul minim de sezoane pentru filtrare:");
                int sezoane = scanner.nextInt();
                for (Serial serial : seriale) {
                    if (serial.filtreaza(sezoane)) {
                        System.out.println(serial);
                    }
                }
                break;
            default:
                System.out.println("Optiune invalida!");
        }
    }
}
