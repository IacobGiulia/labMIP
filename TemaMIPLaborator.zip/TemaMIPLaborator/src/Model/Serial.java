package Model;

public class Serial extends Media implements Filtrabil{

    private int sezoane;

    public Serial(String titlu, int sezoane)
    {
        super(titlu);
        this.sezoane = sezoane;
    }

    public int getSezoane()
    {
        return sezoane;
    }

    public void setSezoane(int sezoane)
    {
        this.sezoane = sezoane;
    }

    @Override
    public String getDetalii()
    {
        return "Serial - Sezoane:" + sezoane;
    }

    @Override
    public boolean filtreaza(Object criteriu)
    {
        if(criteriu instanceof Integer)
            return this.sezoane >= (Integer) criteriu;
        return false;
    }
}
