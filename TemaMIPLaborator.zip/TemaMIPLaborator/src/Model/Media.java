package Model;

public abstract class Media {
    private String titlu;

    public Media(String titlu)
    {
        this.titlu = titlu;
    }

    public String getTitlu()
    {
        return titlu;
    }

    public void setTitlu(String titlu)
    {
        this.titlu = titlu;
    }

    public abstract String getDetalii();

    @Override
    public String toString()
    {
        return titlu + ":" + getDetalii();
    }

}
