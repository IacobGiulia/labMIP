package Model;

public class Film extends Media implements Filtrabil{

    private int an;
    private String gen;
    private double rating;

    public Film(String titlu,  String gen, int an,double rating)
    {
        super(titlu);
        this.an = an;
        this.gen = gen;
        this.rating = rating;
    }

    public int getAn()
    {
        return an;
    }

    public void setAn(int an)
    {
        this.an = an;
    }

    public String getGen()
    {
        return gen;
    }

    public void setGen(String gen)
    {
        this.gen = gen;
    }

    public double getRating()
    {
        return rating;
    }

    public void setRating(double rating)
    {
        this.rating = rating;
    }

    @Override
    public String getDetalii()
    {
        return "Film - Gen: " + gen + ", An: " + an + ", Rating: " + rating;
    }

    @Override
    public boolean filtreaza(Object criteriu)
    {
        if(criteriu instanceof String)
            return this.gen.equalsIgnoreCase((String) criteriu);
        if(criteriu instanceof Double)
            return this.rating >= (Double) criteriu;
        return false;
    }
}
