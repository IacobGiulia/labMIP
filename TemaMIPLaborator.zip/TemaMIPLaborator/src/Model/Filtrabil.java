package Model;

public interface Filtrabil {
    boolean filtreaza(Object criteriu);
}
