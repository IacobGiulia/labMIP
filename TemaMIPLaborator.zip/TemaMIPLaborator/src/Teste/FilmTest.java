package Teste;
import Model.Film;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FilmTest {

    @Test
    public void testFiltrareDupaGen() {
        Film film = new Film("Inception", "Sci-Fi", 2010, 8.8);
        assertTrue(film.filtreaza("Sci-Fi"));
        assertFalse(film.filtreaza("Drama"));
    }

    @Test
    public void testFiltrareDupaRating() {
        Film film = new Film("Inception", "Sci-Fi", 2010, 8.8);
        assertTrue(film.filtreaza(8.0));
        assertFalse(film.filtreaza(9.0));
    }

    @Test
    public void testGetDetalii() {
        Film film = new Film("Inception", "Sci-Fi", 2010, 8.8);
        assertEquals("Film - Gen: Sci-Fi, An: 2010, Rating: 8.8", film.getDetalii());
    }
}
