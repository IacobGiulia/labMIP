package Teste;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import Model.Film;
import Model.Serial;

public class MainTest {

    @Test
    public void testAfisareColectie() {
        List<Film> filme = new ArrayList<>();
        filme.add(new Film("Inception", "Sci-Fi", 2010, 8.8));
        List<Serial> seriale = new ArrayList<>();
        seriale.add(new Serial("Breaking Bad", 5));

        // Capturarea ieșirii pe consolă pentru validare poate fi o provocare
        // Dar pentru simplificare putem valida că lista nu este goală
        assertFalse(filme.isEmpty());
        assertFalse(seriale.isEmpty());
    }

    @Test
    public void testCautareTitlu() {
        List<Film> filme = new ArrayList<>();
        Film film = new Film("Inception", "Sci-Fi", 2010, 8.8);
        filme.add(film);

        // Verifică dacă titlul există
        boolean gasit = false;
        for (Film f : filme) {
            if (f.getTitlu().equalsIgnoreCase("Inception")) {
                gasit = true;
            }
        }
        assertTrue(gasit);
    }
}