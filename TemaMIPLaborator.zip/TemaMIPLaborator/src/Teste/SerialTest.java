package Teste;

import Model.Serial;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SerialTest {

    @Test
    public void testFiltrareDupaSezoane() {
        Serial serial = new Serial("Breaking Bad", 5);
        assertTrue(serial.filtreaza(4));
        assertFalse(serial.filtreaza(6));
    }

    @Test
    public void testGetDetalii() {
        Serial serial = new Serial("Breaking Bad", 5);
        assertEquals("Serial - Sezoane:5", serial.getDetalii());
    }
}